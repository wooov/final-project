const https = require('https');
const url = require('url');

const slackWebhookUrl = process.env.SLACK_WEBHOOK_URL;

exports.handler = function(event, context, callback) {
  const message = JSON.parse(event.Records[0].Sns.Message);

  const slackMessage = {
    channel: "#general",
    text: `<!here> ${message.AlarmName} has been triggered on ${message.Trigger.Namespace}: ${message.NewStateReason}`
  };

  const postData = JSON.stringify(slackMessage);

  const options = url.parse(slackWebhookUrl);
  options.method = 'POST';
  options.headers = {
    'Content-Type': 'application/json',
    'Content-Length': Buffer.byteLength(postData)
  };

  const req = https.request(options, (res) => {
    let data = '';
    res.on('data', (chunk) => {
      data += chunk;
    });

    res.on('end', () => {
      callback(null, data);
    });
  });

  req.write(postData);
  req.end();
};
