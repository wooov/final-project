const AWS = require('aws-sdk');

exports.handler = async (event, context) => {
  // SNS Topic ARN
  const snsTopicArn = process.env.SNS_TOPIC_ARN;

  // Create an SNS object
  const sns = new AWS.SNS();

  try {
    // Get the request URL from the event object
    const requestUrl = event.Records[0].cf.request.uri;
    

    // Check if the request is coming from a specific path
    if (requestUrl.startsWith('https://api.kimdoliving.com/api/get')) {
      // Publish a message to the SNS topic
      await sns.publish({
        TopicArn: snsTopicArn,
        Message: 'Incoming traffic from a specific path detected!',
      }).promise();
    }
  } catch (error) {
    console.log(error);
    return {
      statusCode: 500,
      body: 'Error publishing message to SNS topic',
    };
  }

  return {
    statusCode: 200,
    body: 'Message published to SNS topic',
  };
};